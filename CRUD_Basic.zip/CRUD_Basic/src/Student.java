//import com.sun.istack.internal.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Student extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst;
    ResultSet rs;
    
//    Vector datacol = new Vector();
//    Vector datarow = new Vector();
    
    //  JTable datatable;
    JScrollPane viewdata;
    private int i;
    private int j;
    private int StudentId;
    //  private Object myTable;

    public Student() {
        initComponents();
        this.setSize(1000, 500);
    }

    public void OpenDatabase() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/student", "root", "");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void CloseDatabase() {
        try {
            con.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void insertdata(int StudentId, String StudentName, String StudentBloodGroup, int StudentMobileNo, String StudentAddress) {
        try {
            Statement st = con.createStatement();
            st.executeUpdate("insert into student values("+StudentId+",'"+StudentName+"', '"+StudentBloodGroup+"', "+StudentMobileNo+", '"+StudentAddress+"')");
            JOptionPane.showConfirmDialog(null, "Your Data Has been Inserted", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
        }
    }

    public void deletedata(int StudentId) {
        try {
            Statement st = con.createStatement();
            st.executeUpdate("delete from student where StudentId=" + StudentId);
            JOptionPane.showConfirmDialog(null, "Your Data Has been Deleted", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        labelStudentId = new javax.swing.JLabel();
        txtStudentId = new javax.swing.JTextField();
        labelStudentName = new javax.swing.JLabel();
        txtStudentName = new javax.swing.JTextField();
        labelStudentBloodGroup = new javax.swing.JLabel();
        txtStudentBloodGroup = new javax.swing.JTextField();
        labelStudentPhoneNo = new javax.swing.JLabel();
        txtStudentMobileNo = new javax.swing.JTextField();
        labelStudentAddress = new javax.swing.JLabel();
        txtStudentAddress = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnInsert = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnview = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        myTable = new javax.swing.JTable();
        txtSearch = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 0));
        jPanel1.setForeground(new java.awt.Color(255, 0, 0));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 51));
        jLabel1.setText("         Student   Info");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(30, 120, 180, 22);

        labelStudentId.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        labelStudentId.setForeground(new java.awt.Color(153, 0, 51));
        labelStudentId.setText("StudentId");
        jPanel1.add(labelStudentId);
        labelStudentId.setBounds(0, 160, 90, 30);

        txtStudentId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStudentIdActionPerformed(evt);
            }
        });
        jPanel1.add(txtStudentId);
        txtStudentId.setBounds(150, 160, 180, 30);

        labelStudentName.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        labelStudentName.setForeground(new java.awt.Color(153, 0, 0));
        labelStudentName.setText("StudentName");
        jPanel1.add(labelStudentName);
        labelStudentName.setBounds(0, 210, 110, 20);

        txtStudentName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStudentNameActionPerformed(evt);
            }
        });
        jPanel1.add(txtStudentName);
        txtStudentName.setBounds(150, 210, 180, 30);

        labelStudentBloodGroup.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        labelStudentBloodGroup.setForeground(new java.awt.Color(153, 0, 0));
        labelStudentBloodGroup.setText("StudentBloodGroup");
        jPanel1.add(labelStudentBloodGroup);
        labelStudentBloodGroup.setBounds(0, 270, 130, 15);
        jPanel1.add(txtStudentBloodGroup);
        txtStudentBloodGroup.setBounds(150, 260, 180, 30);

        labelStudentPhoneNo.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        labelStudentPhoneNo.setForeground(new java.awt.Color(153, 51, 0));
        labelStudentPhoneNo.setText("StudentPhoneNo");
        jPanel1.add(labelStudentPhoneNo);
        labelStudentPhoneNo.setBounds(0, 320, 120, 15);
        jPanel1.add(txtStudentMobileNo);
        txtStudentMobileNo.setBounds(150, 310, 180, 30);

        labelStudentAddress.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        labelStudentAddress.setForeground(new java.awt.Color(153, 0, 0));
        labelStudentAddress.setText("StudentAddress");
        jPanel1.add(labelStudentAddress);
        labelStudentAddress.setBounds(0, 370, 110, 20);
        jPanel1.add(txtStudentAddress);
        txtStudentAddress.setBounds(150, 360, 180, 30);

        btnDelete.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(153, 0, 0));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btnDelete);
        btnDelete.setBounds(350, 280, 80, 23);

        btnInsert.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        btnInsert.setForeground(new java.awt.Color(102, 0, 0));
        btnInsert.setText("Insert");
        btnInsert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertActionPerformed(evt);
            }
        });
        jPanel1.add(btnInsert);
        btnInsert.setBounds(350, 230, 80, 23);

        btnUpdate.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(102, 0, 51));
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        jPanel1.add(btnUpdate);
        btnUpdate.setBounds(350, 330, 80, 23);

        btnview.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        btnview.setForeground(new java.awt.Color(102, 51, 0));
        btnview.setText("View");
        btnview.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnviewActionPerformed(evt);
            }
        });
        jPanel1.add(btnview);
        btnview.setBounds(350, 190, 80, 23);

        myTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "StudentId", "StudentName", "StudentBloodGroup", "StudentPhoneNo", "StudentAddress"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        myTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                myTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(myTable);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(440, 70, 480, 270);

        txtSearch.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        txtSearch.setForeground(new java.awt.Color(204, 0, 204));
        txtSearch.setToolTipText("Search\n");
        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        jPanel1.add(txtSearch);
        txtSearch.setBounds(140, 40, 150, 40);

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 255));
        jLabel2.setText("Search Here");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(4, 50, 120, 20);

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 0, 0));
        jLabel3.setText("                  DETAILS ABOUT Student");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(500, 10, 370, 50);

        jButton1.setFont(new java.awt.Font("Tahoma", 3, 10)); // NOI18N
        jButton1.setForeground(new java.awt.Color(153, 0, 51));
        jButton1.setText("Clear");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(350, 50, 70, 21);

        jButton2.setToolTipText("Back to AdminPanel Window");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(893, 0, 40, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 936, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 451, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtStudentIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStudentIdActionPerformed
    }//GEN-LAST:event_txtStudentIdActionPerformed

    private void txtStudentNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStudentNameActionPerformed
    }//GEN-LAST:event_txtStudentNameActionPerformed

    private void btnInsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertActionPerformed

        int StudentId = Integer.parseInt(txtStudentId.getText());
        String StudentName = txtStudentName.getText();
        String StudentBloodGroup = txtStudentBloodGroup.getText();
        int StudentMobileNo = Integer.parseInt(txtStudentMobileNo.getText());
        String StudentAddress = txtStudentAddress.getText();

        try {
            OpenDatabase();
            insertdata(StudentId, StudentName, StudentBloodGroup, StudentMobileNo, StudentAddress);

            CloseDatabase();

        } catch (Exception e) {
            System.out.println(e);
        }
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtStudentBloodGroup.setText("");
        txtStudentMobileNo.setText("");
        txtStudentAddress.setText("");
    }//GEN-LAST:event_btnInsertActionPerformed

    private void btnviewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnviewActionPerformed
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/student", "root", "");

            Statement state = con.createStatement();
            ResultSet rs = state.executeQuery("SELECT * from student");

            ResultSetMetaData rsmetadata = rs.getMetaData();

            int columns = rsmetadata.getColumnCount();
            
            DefaultTableModel dtm = new DefaultTableModel();
            Vector columns_name = new Vector();
//            Vector data_rows = new Vector();

            //for(i=1; i<columns; i++)
            for (i = 1; i < columns + 1; i++) {
                columns_name.addElement(rsmetadata.getColumnName(i));
            }
            dtm.setColumnIdentifiers(columns_name);

            while (rs.next()) {
                Vector data_rows = new Vector();
                for (j = 1; j < columns + 1; j++) {
                    data_rows.addElement(rs.getString(j));
                }
                dtm.addRow(data_rows);
            }
            myTable.setModel(dtm);
        } catch (SQLException ex) {
            // Logger.getLogger(AnotherWindow.class.getName()).log(Level.SEVERE,null , ex);
            JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnviewActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed

        int StudentId = Integer.parseInt(txtStudentId.getText());

        try {
            OpenDatabase();
            deletedata(StudentId);
            CloseDatabase();
            StudentId = 0;
        } catch (Exception e) {
            System.out.println(e);
        }

        if (evt.getSource() == txtStudentId) {
            // int StudentId = Integer.parseInt(txtStudentId.getText());
            try {
                OpenDatabase();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("Select * from student where StudentId=" + StudentId);
                if (rs.next()) {
                    txtStudentName.setText(rs.getString("StudentName"));
                    txtStudentBloodGroup.setText(rs.getString("StudentBloodGroup"));
                    txtStudentMobileNo.setText(String.valueOf(rs.getInt("StudentMobileNo")));
                    txtStudentAddress.setText(rs.getString("StudentAddress"));
                }
                CloseDatabase();
            } catch (Exception e) {
                JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
            }
        }
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtStudentBloodGroup.setText("");
        txtStudentMobileNo.setText("");
        txtStudentAddress.setText("");
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed

        try {
            //  DefaultTableModel model = new DefaultTableModel();




            //  model.setValueAt(txtStudentId.getText() , myTable.getSelectedRow(), 0);
            //  model.setValueAt(txtStudentName.getText(), myTable.getSelectedRow(), 1);
            // model.setValueAt(txtStudentBloodGroup.getText(), myTable.getSelectedRow(), 2);
            //  model.setValueAt(txtStudentMobileNo.getText(), myTable.getSelectedRow(), 3);
            //  model.setValueAt(txtStudentAddress.getText(), myTable.getSelectedRow(), 4);


            String value1 = txtStudentId.getText();
            String value2 = txtStudentName.getText();
            String value3 = txtStudentBloodGroup.getText();
            String value4 = txtStudentMobileNo.getText();
            String value5 = txtStudentAddress.getText();

            String sql = " update student set StudentId = '" + value1 + "' ,StudentName = '" + value2 + "' , StudentBloodGroup = '" + value3 + "' , StudentMobileNo = '" + value4 + "', StudentAddress = '" + value5 + "' where StudentId = '" + value1 + "'";

            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Updated");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        //Update_table();
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtStudentBloodGroup.setText("");
        txtStudentMobileNo.setText("");
        txtStudentAddress.setText("");

    }//GEN-LAST:event_btnUpdateActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased

        try {
            String sql = "select * from student where StudentId = ?";
            pst = con.prepareStatement(sql);
            pst.setString(1, txtSearch.getText());

            rs = pst.executeQuery();

            if (rs.next()) {
                String add1 = rs.getString("StudentId");
                txtStudentId.setText(add1);
                

                String add2 = rs.getString("StudentName");
                txtStudentName.setText(add2);
                System.out.println(add2);

                String add3 = rs.getString("StudentBloodGroup");
                txtStudentBloodGroup.setText(add3);

                String add4 = rs.getString("StudentMobileNo");
                txtStudentMobileNo.setText(add4);

                String add5 = rs.getString("StudentAddress");
                txtStudentAddress.setText(add5);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }


        
        
        
        try {
            String sql = "select * from student where StudentBloodGroup = ?";
            pst = con.prepareStatement(sql);
            pst.setString(1, txtSearch.getText());

            rs = pst.executeQuery();

            if (rs.next()) {
                String add1 = rs.getString("StudentId");
                txtStudentId.setText(add1);

                String add2 = rs.getString("StudentName");
                txtStudentName.setText(add2);

                String add3 = rs.getString("StudentBloodGroup");
                txtStudentBloodGroup.setText(add3);

                String add4 = rs.getString("StudentMobileNo");
                txtStudentMobileNo.setText(add4);

                String add5 = rs.getString("StudentAddress");
                txtStudentAddress.setText(add5);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_txtSearchKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        txtSearch.setText("");
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtStudentBloodGroup.setText("");
        txtStudentMobileNo.setText("");
        txtStudentAddress.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void myTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_myTableMouseClicked

        DefaultTableModel model =  (DefaultTableModel) myTable.getModel();

        txtStudentId.setText(model.getValueAt(myTable.getSelectedRow(), 0).toString());
        txtStudentName.setText(model.getValueAt(myTable.getSelectedRow(), 1).toString());
        txtStudentBloodGroup.setText(model.getValueAt(myTable.getSelectedRow(), 2).toString());
        txtStudentMobileNo.setText(model.getValueAt(myTable.getSelectedRow(), 3).toString());
        txtStudentAddress.setText(model.getValueAt(myTable.getSelectedRow(), 4).toString());
    }//GEN-LAST:event_myTableMouseClicked

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
//        dispose();
//        AdminPanel adminobj2 = new AdminPanel();
//        adminobj2.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Student().setVisible(true);

            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnInsert;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnview;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelStudentAddress;
    private javax.swing.JLabel labelStudentBloodGroup;
    private javax.swing.JLabel labelStudentId;
    private javax.swing.JLabel labelStudentName;
    private javax.swing.JLabel labelStudentPhoneNo;
    private javax.swing.JTable myTable;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtStudentAddress;
    private javax.swing.JTextField txtStudentBloodGroup;
    private javax.swing.JTextField txtStudentId;
    private javax.swing.JTextField txtStudentMobileNo;
    private javax.swing.JTextField txtStudentName;
    // End of variables declaration//GEN-END:variables
}
