/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cityuniversitymanagement;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author shaun
 */
public class meal_manage extends javax.swing.JFrame {

    private final String a;
 private final String userna;
    /**
     * Creates new form meal_manage
     */
    public meal_manage(String table_i,String glo) {
       String a;
        this.a = table_i;
      this.userna = glo;
        initComponents();
        switch (glo) { 
			             
            case "0":
                  System.out.println("inside 0");
                break;
			             default: 
			                 System.out.println("1st"+glo);
                                         try{
            
           Connection myConn = null;
        Statement myStmt1 = null;
        Statement myStmt123 = null;
        ResultSet myRs14 = null;
         ResultSet myRs12 = null;
        String dburl = "jdbc:mysql://localhost:3306/city_reg";
        String user = "root";
        String pass = "";
myConn = (Connection) DriverManager.getConnection(dburl, user, pass);
            myStmt1 = (Statement) myConn.createStatement();
          myStmt123 = (Statement) myConn.createStatement();
          
            
     /*     String up2="UPDATE meal_stu SET Due =Advance - Due WHERE  Id='"+table_i+"'";   
            
             myStmt12.executeLargeUpdate(up2); */
           String up4="UPDATE meal_stu SET due2 =Due - Advance  WHERE  Username='"+glo+"' OR E_mail='"+glo+"'";
            int upd= myStmt123.executeUpdate(up4);
            if(upd>0)
            {
                System.out.println("due updated");
            }
             
       }catch(Exception lo)
       {
           
       }
                                         try{
                                          Connection myConn = null;
        Statement myStmt1 = null;
        Statement myStmt12 = null;
        ResultSet myRs1 = null;
         ResultSet myRs12 = null;
        String dburl = "jdbc:mysql://localhost:3306/city_reg";
        String user = "root";
        String pass = "";
myConn = (Connection) DriverManager.getConnection(dburl, user, pass);
            myStmt1 = (Statement) myConn.createStatement();
          
           String up="SELECT * FROM meal_stu WHERE Username='"+glo+"' OR E_mail='"+glo+"'";
            myRs1 = myStmt1.executeQuery(up);
            if(myRs1.next())
            {
                String name2 = myRs1.getString("Name");
                String id1 = myRs1.getString("Id");
                String Dep = myRs1.getString("Dep");
                String Bat = myRs1.getString("Batch");
                String hallq = myRs1.getString("Hall");
                mname.setText(name2);
                mdep.setText(Dep);
                mbatch.setText(Bat);
                mhall.setText(hallq);
                 String su = myRs1.getString("due2");
                due.setText(su);
                 String dat = myRs1.getString("da");
                  String tr = myRs1.getString("tran");
                  
                
               tranid.setText(tr);
                date.setText(dat);
               jButton1.setEnabled(false);
            }
             
       }catch(Exception lo)
       {
           lo.printStackTrace();
           System.out.println("not fuction glo");
       }
			                 break; 
        }
 switch (table_i) { 
			             
			             
			             default: 
			                 System.out.println("2"+table_i);
                try{
            
           Connection myConn = null;
        Statement myStmt1 = null;
        Statement myStmt123 = null;
        ResultSet myRs14 = null;
         ResultSet myRs12 = null;
        String dburl = "jdbc:mysql://localhost:3306/city_reg";
        String user = "root";
        String pass = "";
myConn = (Connection) DriverManager.getConnection(dburl, user, pass);
            myStmt1 = (Statement) myConn.createStatement();
          myStmt123 = (Statement) myConn.createStatement();
          
            
     /*     String up2="UPDATE meal_stu SET Due =Advance - Due WHERE  Id='"+table_i+"'";   
            
             myStmt12.executeLargeUpdate(up2); */
           String up4="UPDATE meal_stu SET due2 =Due - Advance WHERE  Id='"+table_i+"'";
            int upd= myStmt123.executeUpdate(up4);
            if(upd>0)
            {
                System.out.println("due updated");
            }
             
       }catch(Exception lo)
       {
           
       }
			                 break; 
        }
  
    
                  
        try{
            System.out.println(table_i);
           Connection myConn = null;
        Statement myStmt1 = null;
        Statement myStmt12 = null;
        ResultSet myRs1 = null;
         ResultSet myRs12 = null;
        String dburl = "jdbc:mysql://localhost:3306/city_reg";
        String user = "root";
        String pass = "";
myConn = (Connection) DriverManager.getConnection(dburl, user, pass);
            myStmt1 = (Statement) myConn.createStatement();
          myStmt12 = (Statement) myConn.createStatement();
          
            
     /*     String up2="UPDATE meal_stu SET Due =Advance - Due WHERE  Id='"+table_i+"'";   
            
             myStmt12.executeLargeUpdate(up2); */
           String up="SELECT * FROM meal_stu WHERE Id='"+table_i+"'";
            myRs1 = myStmt1.executeQuery(up);
            if(myRs1.next())
            {
                String name2 = myRs1.getString("Name");
                String id1 = myRs1.getString("Id");
                String Dep = myRs1.getString("Dep");
                String Bat = myRs1.getString("Batch");
                String hallq = myRs1.getString("Hall");
                mname.setText(name2);
                mdep.setText(Dep);
                mbatch.setText(Bat);
                mhall.setText(hallq);
                 String su = myRs1.getString("due2");
                  String dat = myRs1.getString("da");
                  String tr = myRs1.getString("tran");
                  
                due.setText(su);
               tranid.setText(tr);
                date.setText(dat);
                jButton1.setEnabled(true);
            }
             
       }catch(Exception lo)
       {
           
       }
    
    }

    meal_manage() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        mname = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        mdep = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        mhall = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        mbatch = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        due = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tranid = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Name:");

        jLabel2.setText("Department:");

        jLabel3.setText("Hall name:");

        jLabel4.setText("Batch:");

        jLabel5.setText("Due Payment:");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Student Profile");

        jButton1.setText("RENEW PAYMENT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setText("Last renew requested:");

        jLabel8.setText("transaction id:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(215, 215, 215)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(mname, javax.swing.GroupLayout.DEFAULT_SIZE, 306, Short.MAX_VALUE)
                            .addComponent(mdep)
                            .addComponent(mhall)
                            .addComponent(mbatch)
                            .addComponent(due)
                            .addComponent(date)
                            .addComponent(tranid)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(238, 238, 238)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(152, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel6)
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(mname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(mdep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(mhall, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(mbatch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(due, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tranid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try{
           Connection myConn = null;
        Statement myStmt1 = null;
        Statement myStmt12 = null;
        ResultSet myRs1 = null;
         ResultSet myRs12 = null;
        String dburl = "jdbc:mysql://localhost:3306/city_reg";
        String user = "root";
        String pass = "";
myConn = (Connection) DriverManager.getConnection(dburl, user, pass);
            myStmt1 = (Statement) myConn.createStatement();
          
           String up="UPDATE meal_stu SET Due='0',Advance='0' WHERE Id='"+a+"'";
            int aaq = myStmt1.executeUpdate(up);
            if(aaq>0)
            {
                JOptionPane.showMessageDialog(null,"Student renewal successful!");
                dispose();
               
            }
             
       }catch(Exception lo)
       {
           lo.printStackTrace();
       }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(meal_manage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(meal_manage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(meal_manage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(meal_manage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField date;
    private javax.swing.JTextField due;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField mbatch;
    private javax.swing.JTextField mdep;
    private javax.swing.JTextField mhall;
    private javax.swing.JTextField mname;
    private javax.swing.JTextField tranid;
    // End of variables declaration//GEN-END:variables
}
