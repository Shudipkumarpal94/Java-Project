
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import static org.omg.CORBA.AnySeqHelper.insert;

public class Student extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst;
    ResultSet rs;
    JScrollPane viewdata;
    private int i;
    private int j;
    private int student_id;

    public Student() {
        initComponents();
        this.setSize(1000, 500);
    }

    public void OpenDatabase() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info_student", "root", "");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void CloseDatabase() {
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void insertdata(int student_id, String student_name, String Subject, int Mid, int Final, int Others, String Grade) {
        try {
            Statement st = con.createStatement();
            st.executeUpdate("insert into student_details values(" + student_id + ",'" + student_name + "','" + Subject + "'," + Mid + "," + Final + "," + Others + ",'" + Grade + "')");
            JOptionPane.showConfirmDialog(null, "Your Data Has been Inserted", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
        }
    }

    public void deletedata(int student_id) {
        try {
            Statement st = con.createStatement();
            st.executeUpdate("delete from student_details where student_id=" + student_id);
            JOptionPane.showConfirmDialog(null, "Your Data Has been Deleted", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPopupMenu2 = new javax.swing.JPopupMenu();
        label1 = new java.awt.Label();
        popupMenu1 = new java.awt.PopupMenu();
        jPanel1 = new javax.swing.JPanel();
        Id = new javax.swing.JLabel();
        txtStudentId = new javax.swing.JTextField();
        Mid = new javax.swing.JLabel();
        txtMid = new javax.swing.JTextField();
        Final = new javax.swing.JLabel();
        txtFinal = new javax.swing.JTextField();
        Others = new javax.swing.JLabel();
        txtOthers = new javax.swing.JTextField();
        btDelete = new javax.swing.JButton();
        btAdd = new javax.swing.JButton();
        btUpdate = new javax.swing.JButton();
        btView = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        myTable = new javax.swing.JTable();
        txtSearch = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btClear = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtStudentName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtSubject = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtGrade = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        label1.setText("label1");

        popupMenu1.setLabel("popupMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setForeground(new java.awt.Color(255, 0, 0));
        jPanel1.setLayout(null);

        Id.setText("Student Id");
        jPanel1.add(Id);
        Id.setBounds(20, 80, 90, 20);

        txtStudentId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtStudentIdActionPerformed(evt);
            }
        });
        jPanel1.add(txtStudentId);
        txtStudentId.setBounds(140, 80, 180, 20);

        Mid.setText("Mid");
        jPanel1.add(Mid);
        Mid.setBounds(20, 200, 110, 20);

        txtMid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMidActionPerformed(evt);
            }
        });
        jPanel1.add(txtMid);
        txtMid.setBounds(140, 200, 180, 20);

        Final.setText("Final");
        jPanel1.add(Final);
        Final.setBounds(20, 240, 110, 14);
        jPanel1.add(txtFinal);
        txtFinal.setBounds(140, 240, 180, 20);

        Others.setText("Others");
        jPanel1.add(Others);
        Others.setBounds(20, 280, 100, 14);
        jPanel1.add(txtOthers);
        txtOthers.setBounds(140, 280, 180, 20);

        btDelete.setText("Delete");
        btDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btDelete);
        btDelete.setBounds(240, 370, 80, 23);

        btAdd.setText("Add");
        btAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddActionPerformed(evt);
            }
        });
        jPanel1.add(btAdd);
        btAdd.setBounds(130, 370, 80, 23);

        btUpdate.setText("Update");
        btUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btUpdateActionPerformed(evt);
            }
        });
        jPanel1.add(btUpdate);
        btUpdate.setBounds(340, 370, 80, 23);

        btView.setText("View");
        btView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btViewActionPerformed(evt);
            }
        });
        jPanel1.add(btView);
        btView.setBounds(20, 370, 80, 23);

        myTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "student_id", "student_name", "subject", "mid", "final", "others", "grade"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        myTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                myTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(myTable);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(440, 0, 520, 440);

        txtSearch.setToolTipText("Search\n");
        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        jPanel1.add(txtSearch);
        txtSearch.setBounds(140, 40, 180, 20);

        jLabel2.setText("Search");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 40, 120, 20);

        btClear.setText("Clear");
        btClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btClearActionPerformed(evt);
            }
        });
        jPanel1.add(btClear);
        btClear.setBounds(340, 40, 70, 20);

        jLabel1.setText("Student Name");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 120, 90, 14);
        jPanel1.add(txtStudentName);
        txtStudentName.setBounds(140, 120, 180, 20);

        jLabel3.setText("Subject");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 160, 60, 14);
        jPanel1.add(txtSubject);
        txtSubject.setBounds(140, 160, 180, 20);

        jLabel4.setText("Grade");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 320, 60, 14);
        jPanel1.add(txtGrade);
        txtGrade.setBounds(140, 320, 180, 20);

        jLabel5.setText("Design By Shudip, Mahthir, Jubayer");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(110, 420, 240, 20);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 958, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtStudentIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtStudentIdActionPerformed
    }//GEN-LAST:event_txtStudentIdActionPerformed

    private void txtMidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMidActionPerformed
    }//GEN-LAST:event_txtMidActionPerformed

    private void btAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddActionPerformed

        int student_id = Integer.parseInt(txtStudentId.getText());
        String student_name = txtStudentName.getText();
        String Subject = txtSubject.getText();
        int Mid = Integer.parseInt(txtMid.getText());
        int Final = Integer.parseInt(txtFinal.getText());
        int Others = Integer.parseInt(txtOthers.getText());
        String Grade = txtGrade.getText();

        try {
            OpenDatabase();
            insertdata(student_id, student_name, Subject, Mid, Final, Others, Grade);

        } catch (Exception e) {
            System.out.println(e);
        }
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtSubject.setText("");
        txtMid.setText("");
        txtFinal.setText("");
        txtOthers.setText("");
        txtGrade.setText("");
    }//GEN-LAST:event_btAddActionPerformed

    private void btViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btViewActionPerformed
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info_student", "root", "");

            Statement state = con.createStatement();
            ResultSet rs = state.executeQuery("SELECT * from student_details");

            ResultSetMetaData rsmetadata = rs.getMetaData();

            int columns = rsmetadata.getColumnCount();

            DefaultTableModel dtm = new DefaultTableModel();
            Vector columns_name = new Vector();
            for (i = 1; i < columns + 1; i++) {
                columns_name.addElement(rsmetadata.getColumnName(i));
            }
            dtm.setColumnIdentifiers(columns_name);

            while (rs.next()) {
                Vector data_rows = new Vector();
                for (j = 1; j < columns + 1; j++) {
                    data_rows.addElement(rs.getString(j));
                }
                dtm.addRow(data_rows);
            }
            myTable.setModel(dtm);
        } catch (SQLException ex) {
            JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btViewActionPerformed

    private void btDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDeleteActionPerformed

        int student_id = Integer.parseInt(txtStudentId.getText());

        try {
            OpenDatabase();
            deletedata(student_id);
            CloseDatabase();
            student_id = 0;
        } catch (Exception e) {
            System.out.println(e);
        }

        if (evt.getSource() == txtStudentId) {
            try {
                OpenDatabase();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("Select * from student_details where student_id=" + student_id);
                if (rs.next()) {
                    txtStudentName.setText(rs.getString("Student_name"));
                    txtSubject.setText(rs.getString("subject"));
                    txtMid.setText(rs.getString("mid"));
                    txtFinal.setText(rs.getString("final"));
                    txtOthers.setText(rs.getString("others"));
                    txtGrade.setText(rs.getString("grade"));

                }
                CloseDatabase();
            } catch (Exception e) {
                JOptionPane.showConfirmDialog(null, "Problem in Database connectivity or Data", "Result", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
            }
        }
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtSubject.setText("");
        txtMid.setText("");
        txtFinal.setText("");
        txtOthers.setText("");
        txtGrade.setText("");

    }//GEN-LAST:event_btDeleteActionPerformed

    private void btUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btUpdateActionPerformed

        try {
            String value1 = txtStudentId.getText();
            String value2 = txtStudentName.getText();
            String value3 = txtSubject.getText();
            String value4 = txtMid.getText();
            String value5 = txtFinal.getText();
            String value6 = txtOthers.getText();
            String value7 = txtGrade.getText();

            String sql = " update student_details set student_id = '" + value1 + "' ,student_name = '" + value2 + "' , subject = '" + value3 + "' , mid = '" + value4 + "', final = '" + value5 + "', others = '" + value6 + "', grade = '" + value7 + "' where student_id = '" + value1 + "'";

            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Updated");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtSubject.setText("");
        txtMid.setText("");
        txtFinal.setText("");
        txtOthers.setText("");
        txtGrade.setText("");


    }//GEN-LAST:event_btUpdateActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased

        try {
            String sql = "select * from student_details where student_id = ?";
            pst = con.prepareStatement(sql);
            pst.setString(1, txtSearch.getText());

            rs = pst.executeQuery();

            if (rs.next()) {
                String add1 = rs.getString("student_id");
                txtStudentId.setText(add1);
                System.out.println(add1);

                String add2 = rs.getString("student_name");
                txtStudentName.setText(add2);
                System.out.println(add2);

                String add3 = rs.getString("subject");
                txtSubject.setText(add3);
                System.out.println(add3);

                String add4 = rs.getString("mid");
                txtMid.setText(add4);
                System.out.println(add4);

                String add5 = rs.getString("final");
                txtFinal.setText(add5);
                System.out.println(add5);

                String add6 = rs.getString("others");
                txtOthers.setText(add6);
                System.out.println(add6);
                
                String add7 = rs.getString("grade");
                txtGrade.setText(add7);
                System.out.println(add7);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        try {
            String sql = "select * from student_details where student_name = ?";
            pst = con.prepareStatement(sql);
            pst.setString(1, txtSearch.getText());

            rs = pst.executeQuery();

            if (rs.next()) {
                String add1 = rs.getString("student_id");
                txtStudentId.setText(add1);
                System.out.println(add1);

                String add2 = rs.getString("student_name");
                txtStudentName.setText(add2);
                System.out.println(add2);

                String add3 = rs.getString("subject");
                txtSubject.setText(add3);
                System.out.println(add3);

                String add4 = rs.getString("mid");
                txtMid.setText(add4);
                System.out.println(add4);

                String add5 = rs.getString("final");
                txtFinal.setText(add5);
                System.out.println(add5);

                String add6 = rs.getString("others");
                txtOthers.setText(add6);
                System.out.println(add6);

                String add7 = rs.getString("grade");
                txtGrade.setText(add7);
                System.out.println(add7);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_txtSearchKeyReleased

    private void btClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btClearActionPerformed
        txtSearch.setText("");
        txtStudentId.setText("");
        txtStudentName.setText("");
        txtSubject.setText("");
        txtMid.setText("");
        txtFinal.setText("");
        txtOthers.setText("");
        txtGrade.setText("");

    }//GEN-LAST:event_btClearActionPerformed

    private void myTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_myTableMouseClicked

        DefaultTableModel model = (DefaultTableModel) myTable.getModel();

        txtStudentId.setText(model.getValueAt(myTable.getSelectedRow(), 0).toString());
        txtStudentName.setText(model.getValueAt(myTable.getSelectedRow(), 1).toString());
        txtSubject.setText(model.getValueAt(myTable.getSelectedRow(), 2).toString());
        txtMid.setText(model.getValueAt(myTable.getSelectedRow(), 3).toString());
        txtFinal.setText(model.getValueAt(myTable.getSelectedRow(), 4).toString());
        txtOthers.setText(model.getValueAt(myTable.getSelectedRow(), 5).toString());
        txtGrade.setText(model.getValueAt(myTable.getSelectedRow(), 6).toString());

    }//GEN-LAST:event_myTableMouseClicked

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed

    }//GEN-LAST:event_txtSearchActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Student().setVisible(true);

            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Final;
    private javax.swing.JLabel Id;
    private javax.swing.JLabel Mid;
    private javax.swing.JLabel Others;
    private javax.swing.JButton btAdd;
    private javax.swing.JButton btClear;
    private javax.swing.JButton btDelete;
    private javax.swing.JButton btUpdate;
    private javax.swing.JButton btView;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JScrollPane jScrollPane1;
    private java.awt.Label label1;
    private javax.swing.JTable myTable;
    private java.awt.PopupMenu popupMenu1;
    private javax.swing.JTextField txtFinal;
    private javax.swing.JTextField txtGrade;
    private javax.swing.JTextField txtMid;
    private javax.swing.JTextField txtOthers;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtStudentId;
    private javax.swing.JTextField txtStudentName;
    private javax.swing.JTextField txtSubject;
    // End of variables declaration//GEN-END:variables

}
