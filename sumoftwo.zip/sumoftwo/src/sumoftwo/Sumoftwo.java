package sumoftwo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static javax.swing.JFrame.*;


public class Sumoftwo {


    public static void main(String[] args) {

        JFrame frame = new JFrame("Sum of two"); // Creats a frame with title "Sum of two"
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE); // Stops prgram execution when close button is clicked
        frame.setSize(220, 250);
        frame.setLayout(new FlowLayout());
        JLabel label1 = new JLabel("Enter number1");
        JLabel label2 = new JLabel("Enter number2");
        JLabel label3 = new JLabel("Sum is ");

        JTextField txt1 = new JTextField(15);
        JTextField txt2 = new JTextField(15);
        JTextField txt3 = new JTextField(15);

        JButton btn = new JButton("Add");

        frame.add(label1);
        frame.add(txt1);

        frame.add(label2);
        frame.add(txt2);

        frame.add(label3);
        frame.add(txt3);

        frame.add(btn);

        frame.setVisible(true);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                double sum = Double.parseDouble(txt1.getText()) + Double.parseDouble(txt2.getText());
                String ans = String.format("%.2f", sum);
                txt3.setText(ans);

            }
        }) ;

    }

}
